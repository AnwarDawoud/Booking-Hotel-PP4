# hotels_booking\hotel_your_choice\forms.py
from django import forms
from django.contrib.auth import get_user_model
from allauth.account.forms import SignupForm, LoginForm
from .models import Hotel

User = get_user_model()

class CustomLoginForm(LoginForm):
    pass

class CustomRegistrationForm(SignupForm):
    first_name = forms.CharField(max_length=30, label='First Name')
    last_name = forms.CharField(max_length=30, label='Last Name')
    contact_number = forms.CharField(max_length=15, required=False, label='Contact Number')

    def clean_email(self):
        email = super().clean_email()
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('This email address is already in use. Please supply a different email address.')
        return email

    def save(self, request):
        user = super(CustomRegistrationForm, self).save(request)
        # Custom logic after user registration if needed
        return user

class YourBookingForm(forms.Form):
    hotel = forms.ModelChoiceField(queryset=Hotel.objects.all(), label='Select a Hotel')
    check_in = forms.DateField()
    check_out = forms.DateField()
    guests = forms.IntegerField()

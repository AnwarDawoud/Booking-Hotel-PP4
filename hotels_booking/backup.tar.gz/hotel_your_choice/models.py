# hotels_booking\hotel_your_choice\models.py
from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser

class Hotel(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    address = models.CharField(max_length=255)

class Booking(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    hotel = models.ForeignKey(Hotel, on_delete=models.CASCADE)
    check_in = models.DateField()
    check_out = models.DateField()
    guests = models.PositiveIntegerField()
    issued_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.hotel.name} - {self.check_in} to {self.check_out}"

class HotelYourChoiceBooking(models.Model):
    check_in = models.DateField()
    check_out = models.DateField()
    guests = models.PositiveIntegerField()
    hotel = models.ForeignKey('HotelYourChoiceHotel', on_delete=models.DO_NOTHING)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'hotel_your_choice_booking'

class HotelYourChoiceHotel(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    address = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'hotel_your_choice_hotel'

class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.username

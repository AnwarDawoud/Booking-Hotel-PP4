# hotels_booking/hotel_your_choice/views.py
import logging
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.db.models import Max, F, Window
from django.db.models.functions import RowNumber
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from allauth.account.views import SignupView
from .forms import YourBookingForm, CustomRegistrationForm, CustomLoginForm
from .models import Hotel, Booking
from django.contrib.auth.hashers import make_password

logger = logging.getLogger(__name__)

def home(request):
    hotels = Hotel.objects.all()
    return render(request, 'hotel_your_choice/home.html', {'hotels': hotels})

@login_required
def dashboard(request):
    logger.debug("Fetching bookings for user: %s", request.user)

    window = Window(
        expression=RowNumber(),
        partition_by=[F('hotel')],
        order_by=[F('check_in').desc()]
    )

    latest_bookings = Booking.objects.filter(
    user=request.user
).annotate(
    row_number=window
)[:1]

    return render(request, 'hotel_your_choice/dashboard.html', {'filtered_bookings': latest_bookings})

@login_required
def book_hotel(request, hotel_id):
    logger.debug("Received hotel_id: %s", hotel_id)

    available_hotels = Hotel.objects.all()

    if request.method == 'POST':
        form = YourBookingForm(request.POST)
        if form.is_valid():
            selected_hotel_id = form.cleaned_data['hotel'].id
            selected_hotel = get_object_or_404(Hotel, pk=selected_hotel_id)
            logger.debug("Selected hotel from form: %s", selected_hotel.name)

            check_in = form.cleaned_data['check_in']
            check_out = form.cleaned_data['check_out']
            guests = form.cleaned_data['guests']

            Booking.objects.create(
                user=request.user,
                hotel=selected_hotel,
                check_in=check_in,
                check_out=check_out,
                guests=guests
            )

            logger.debug("Booking created successfully")

            return redirect('hotel_your_choice:dashboard')

    else:
        form = YourBookingForm()

    return render(request, 'hotel_your_choice/book_hotel.html', {'form': form, 'available_hotels': available_hotels, 'selected_hotel_id': hotel_id})

class CustomSignupView(SignupView):
    template_name = 'account/signup.html'
    form_class = CustomRegistrationForm

    def form_valid(self, form):
        response = super().form_valid(form)
        # Your custom logic here
        return response

    def get_success_url(self):
        return reverse('name_of_success_url')

def register_view(request):
    if request.method == 'POST':
        form = CustomRegistrationForm(request.POST)
        if form.is_valid():
            form.save(request)
            # Custom logic after user registration if needed
            return redirect('some_redirect_url')
    else:
        form = CustomRegistrationForm()

    return render(request, 'account/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = CustomLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')

            user = authenticate(request, username=username, password=password)

            if user:
                login(request, user)
                messages.success(request, f"Welcome, {username}! You are now logged in.")
                return HttpResponseRedirect(reverse('hotel_your_choice:home'))
            else:
                messages.error(request, "Login failed. Please enter a correct username and password.")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"Login failed: {field} - {error}")
    else:
        form = CustomLoginForm()

    return render(request, 'hotel_your_choice/login.html', {'form': form})

def password_reset_view(request):
    # Your implementation for password_reset_view view
    pass

# context_processors.py
def welcome_message(request):
    user_welcome = ""
    if request.user.is_authenticated:
        user_welcome = f"Welcome, {request.user.username}!"
    return {'user_welcome': user_welcome}

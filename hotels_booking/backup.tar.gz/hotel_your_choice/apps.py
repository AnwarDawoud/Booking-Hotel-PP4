# hotels_booking\hotel_your_choice\apps.py
from django.apps import AppConfig

class HotelYourChoiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hotel_your_choice'

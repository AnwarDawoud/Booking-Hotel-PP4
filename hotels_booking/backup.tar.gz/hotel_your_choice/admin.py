# hotels_booking\hotel_your_choice\admin.py
from django.contrib import admin
from .models import Hotel, Booking
from allauth.account.models import EmailAddress as AllAuthEmailAddress

admin.site.register(Hotel)
admin.site.register(Booking)

# Unregister EmailAddress model from allauth
if admin.site.is_registered(AllAuthEmailAddress):
    admin.site.unregister(AllAuthEmailAddress)

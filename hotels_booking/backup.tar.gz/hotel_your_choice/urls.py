# hotels_booking\hotel_your_choice\urls.py
from django.conf import settings
from django.conf.urls.static import static
from .views import home, dashboard, book_hotel, register_view, login_view, password_reset_view
from django.urls import path

app_name = 'hotel_your_choice'

urlpatterns = [
    path('', home, name='home'),
    path('dashboard/', dashboard, name='dashboard'),
    path('book_hotel/<int:hotel_id>/', book_hotel, name='book_hotel'),
    path('register/', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('password_reset/', password_reset_view, name='password_reset'),
]

# Add this to serve static files during development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
